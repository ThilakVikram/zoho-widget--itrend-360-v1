let appName = "itrend-360-v1"
let reportName = "All_Quotations"
let id = ""
let field_config = "detail_view"