let DATA = {
    "code": 3000,
    "data": {
        "Target_Marketplace": "US",
        "Category": "Automotive",
        "Received_Date_Marketing_Manager": "",
        "Have_you_analysed_the_marketing_trend_of_the_product": "Trends are Really Goods Product Sold more than 30% from the past year",
        "Submitter_email_ID": "scm@itrendsolution.com",
        "Decision_MD": "false",
        "Priority_of_the_Request": "High",
        "Have_you_checked_it_is_profitable_If_yes_Justify_in_remarks": "",
        "Notes_to_Approver": "Summer Season Product High Demand and Profit",
        "Have_you_checked_the_and_confirm_that_the_Product_Owner_s_submission_is_complete_and_clear": "",
        "Quote_Confirmation": {},
        "ID": "4639844000001243011",
        "Have_you_verified_that_the_seasonal_relevance_aligns_with_expected_sales_peaks": "",
        "Season": "Summer",
        "Have_you_submitted_the_Product_justification": "yes submitted",
        "How_confident_on_the_product": "High",
        "Requestor_Name": "Thilak Vikram R",
        "Have_you_checked_what_impact_will_this_order_have_on_business_If_yes_write_attach_in_remarks": "",
        "Have_you_estimate_the_sales_justification_for_this_order_monthwise": "yes have submited",
        "Status_Marketing_Manager": "",
        "Have_you_evaluated_if_pricing_demand_forecast_and_seasonality_are_realistically_assessed": "",
        "Completed_Date_Marketing_Managerf": "11/7/2000",
        "Reference": "High Performance",
        "Received_Date_MD": "",
        "Purchase_Request_Number": "22",
        "Expected_Date": "10-Oct-2025",
        "Status_MD": "",
        "Decision_Marketing_Manager": "false",
        "Have_you_evaluated_whether_the_expected_ROI_will_cover_the_cost_and_yield_sufficient_profit": "",
        "Any_specific_Quality_need_to_be_checked_while_QC": "",
        "Have_you_checked_the_Last_two_months_sales_history_of_the_product": "no its not in trend",
        "Purchase_Request_Line_Items": [
            {
                "ID": "4639844000001243007",
                "Purchase_Request_Item_Number": "25",
                "zc_display_value": "25"
            }
        ],
        "In_previous_for_which_month_sales_we_placed_this_order": "",
        "Have_you_ensured_that_the_market_analysis_aligns_with_overall_business_goals": "",
        "By_when_you_need_this_order_to_be_available": "31-Oct-2025",
        "Have_you_considered_the_risk_of_price_volatility_drop_or_increase": "",
        "Line_Items": [
            {
                "Decision_QC": "false",
                "Advance_Payment_Request_Line_Items": {},
                "Completed_Date_QC": "",
                "Estimated_ROI": "6.50",
                "FBA": "120",
                "From_Date": "01-Jan-2025",
                "Quantity": "10000",
                "Target_Price": "2.50",
                "Purchase_Request_Item_Number": "25",
                "AWD": "120",
                "From_Date1": "01-Jan-2026",
                "Item": {
                    "name": "Econour Autovir Sunshade XXXX-Large (75 inches x 37 inches) SS NW",
                    "ID": "5526035000082106061",
                    "cf_asin": "B0F1T6NS26",
                    "sku": "Auto_XL_Ss_Nw",
                    "zc_display_value": "Econour Autovir Sunshade XXXX-Large (75 inches x 37 inches) SS NW - B0F1T6NS26 - Auto_XL_Ss_Nw"
                },
                "Estimated_Profit": "60000.00",
                "Estimated_Unit_Sold": "20000",
                "China": "5000",
                "Estimated_Margin": "300.00",
                "Days": "180",
                "ID": "4639844000001243007",
                "Enhancement": "Need to Check Connector Quality\nSun Reflection should be check and verified\nMaterial Quality to be checked and Confirmed",
                "zc_display_value": "25 120  5000  180 false Need to Check Connector Quality\nSun Reflection should be check and verified\nMaterial Quality to be checked and Confirmed 300.00 60000.00 6.50 20000 120 01-Jan-2026 01-Jan-2025 Econour Autovir Sunshade XXXX-Large (75 inches x 37 inches) SS NW - B0F1T6NS26 - Auto_XL_Ss_Nw 10000 2.50"
            }
        ],
        "Have_you_checked_the_Product_Justification_ROI_Marketing_plan_Forcast_Plant1": "",
        "Completed_Date_MD": ""
    }
}