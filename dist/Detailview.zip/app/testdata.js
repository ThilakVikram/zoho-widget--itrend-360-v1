let DATA = {
    "code": 3000,
    "data": {
        "To_Date1": "",
        "Warehouse": "",
        "FBA": "",
        "From_Date": "",
        "Target_Price": "",
        "Purchase_Request_Item_Number": "24",
        "AWD": "",
        "Have_you_checked_any_enchancement_in_the_product": "",
        "Item": {
            "name": "Autovir Sun Shade for Tesla Model 3/Y Cars XXX-Large (56 x 36)SS",
            "ID": "5526035000001073077",
            "cf_asin": "B0CR6FM433",
            "sku": "Autov-210DSC04-TeslaSS",
            "zc_display_value": "Autovir Sun Shade for Tesla Model 3/Y Cars XXX-Large (56 x 36)SS - B0CR6FM433 - Autov-210DSC04-TeslaSS"
        },
        "Estimated_Margin": "",
        "China": "",
        "In_Transit_to_Destination_Port": "",
        "Days": "",
        "Specification_Sheet": "",
        "Profit": "",
        "ID": "4639844000001183125",
        "Enhancement": "",
        "To_Date": "",
        "Have_you_understands_the_product_s_functionality_usage_environment_and_performance_expectations": "",
        "Estimated_ROI": "",
        "Quantity": "",
        "ROI": "",
        "From_Date1": "",
        "Units_Sold": "",
        "Estimated_Unit_Sold": "",
        "Estimated_Profit": "",
        "Margin": ""
    }
}