let DATA = {
    "code": 3000,
    "data": {
        "Target_Marketplace": "",
        "Category": "",
        "Received_Date_Marketing_Manager": "",
        "Have_you_analysed_the_marketing_trend_of_the_product": "",
        "Blueprint.Status": {
            "ID": "4639844000001221007",
            "zc_display_value": "Active"
        },
        "PR_Status": "false",
        "Submitter_email_ID": "scm@itrendsolution.com",
        "Decision_MD": "false",
        "Priority_of_the_Request": "",
        "Have_you_checked_it_is_profitable_If_yes_Justify_in_remarks": "",
        "Notes_to_Approver": "",
        "Have_you_checked_the_and_confirm_that_the_Product_Owner_s_submission_is_complete_and_clear": "",
        "Quote_Confirmation": {},
        "ID": "4639844000001221003",
        "Have_you_verified_that_the_seasonal_relevance_aligns_with_expected_sales_peaks": "",
        "Season": "",
        "Have_you_submitted_the_Product_justification": "",
        "How_confident_on_the_product": "",
        "Requestor_Name": "",
        "Have_you_checked_what_impact_will_this_order_have_on_business_If_yes_write_attach_in_remarks": "",
        "Have_you_estimate_the_sales_justification_for_this_order_monthwise": "",
        "Status_Marketing_Manager": "",
        "Have_you_evaluated_if_pricing_demand_forecast_and_seasonality_are_realistically_assessed": "",
        "Completed_Date_Marketing_Managerf": "",
        "Blueprint.Name": {
            "ID": "4639844000001221007",
            "zc_display_value": "Purchase Request"
        },
        "Reference": "",
        "Received_Date_MD": "",
        "Purchase_Request_Number": "21",
        "Expected_Date": "",
        "Status_MD": "",
        "Decision_Marketing_Manager": "false",
        "Blueprint.Current_Stage": {
            "ID": "4639844000001221007",
            "zc_display_value": "PR Created"
        },
        "Have_you_evaluated_whether_the_expected_ROI_will_cover_the_cost_and_yield_sufficient_profit": "",
        "Any_specific_Quality_need_to_be_checked_while_QC": "",
        "Have_you_checked_the_Last_two_months_sales_history_of_the_product": "",
        "Purchase_Request_Line_Items": [],
        "In_previous_for_which_month_sales_we_placed_this_order": "",
        "Have_you_ensured_that_the_market_analysis_aligns_with_overall_business_goals": "",
        "By_when_you_need_this_order_to_be_available": "",
        "Have_you_considered_the_risk_of_price_volatility_drop_or_increase": "",
        "Line_Items": [],
        "Have_you_checked_the_Product_Justification_ROI_Marketing_plan_Forcast_Plant1": "",
        "Completed_Date_MD": ""
    }
}