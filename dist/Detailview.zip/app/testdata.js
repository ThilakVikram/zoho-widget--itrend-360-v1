let DATA = {
    "code": 3000,
    "data": {
        "Shipment_Term": "FOB",
        "Decision_QC": "false",
        "Vendor_Name": "name1",
        "Completed_Date_QC": "",
        "Port": "Ningbo",
        "Did_the_Product_pass_all_the_Quality_tests": "",
        "Purchase_Request_Line_Items.Target_Price": "",
        "Quantity": "12",
        "Received_Date_QC": "",
        "Have_you_created_a_complete_inspection_report_for_each_sample": "",
        "Purchase_Request_Line_Items.Quantity": "",
        "Quotation": "",
        "Date_field": "11-Oct-2025",
        "Purchase_Request_Line_Items": {
            "ID": "4639844000001183121",
            "Purchase_Request_Item_Number": "23",
            "zc_display_value": "23"
        },
        "Item_Name": {
            "name": "Amazon Customer Return - Reimbursement",
            "ID": "5526035000112150235",
            "cf_asin": "AMZREIMBCUSRET",
            "sku": "AMZ_FBA_Reimb_Customer_Return",
            "zc_display_value": "Amazon Customer Return - Reimbursement - AMZREIMBCUSRET - AMZ_FBA_Reimb_Customer_Return"
        },
        "Quote_Price": "12.00",
        "Company_Name": "fnfonoi",
        "ID": "4639844000001243003",
        "Lead_Time": "12",
        "Have_you_verified_sample_against_the_Specification_Sheet": "",
        "Quotation_Number": "3",
        "Added_Time": "11-Oct-2025 14:48:09"
    }
}